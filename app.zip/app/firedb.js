import { db } from "./firebase";
import { v4 as uuid } from "uuid";
import {
    getFirestore,
    query,
    getDocs,
    collection,
    where,
    addDoc,
    getDoc,
    setDoc,
    doc,
    updateDoc,
    arrayUnion,
    Timestamp,
  } from "firebase/firestore";


const addUserInfotoCloudDB = async(uid, photourl, username, email,gender,phone, fullname)=>{
    try{
        const data = {
            Uid:uid,
            Username:username,
            Fullname:fullname,
            Email:email,
            Gender:gender,
            Phone:phone,
            PhotoUrl:photourl,
            Friends:{},
            onlinestat:"online"       

        }
        await setDoc(doc(db, "users", uid), data);

    }
    catch(err){
        console.log(err);
    }
}



const ChatList = async (uid)=> {
    try{
        const userDocRef = doc(db, 'users', uid);
        const userDocSnapshot = await getDoc(userDocRef);
        const userData = userDocSnapshot.data();
        // console.log(userData);
        return userData.Chats;
    }
    catch(err){
        console.log(err);
        
    }

}

const userInfo = async (uid) => {
    try{
        const userDocRef = doc(db, 'users', uid);
        const userDocSnapshot = await getDoc(userDocRef);
        const userData = userDocSnapshot.data();
        // console.log(userData);
        return {
            Fullname: userData.Fullname,
            Uid: userData.Uid,
            PhotoUrl: userData.PhotoUrl,
            Email: userData.Email,
            Gender: userData.Gender,
            Phone:userData.Phone

        }

    }
    catch(err){
        console.log(err);
        
    }
}

const updateInfoarray = async (uid,name,gender,phone, photourl) => {
    try{
        const userDocRef = doc(db, 'users', uid);
        console.log("update call ",[uid,name,gender,phone, photourl]);
        await updateDoc(userDocRef, {
            Fullname: name,
            PhotoUrl:photourl,
            Gender:gender,
            Phone:phone

          });
        return "ProfileDB updated"

    }
    catch(err){
        console.log(err);
        
        
    }
}

const SendTxt = async (ChatId,text,uid)=>{
    console.log(ChatId,text,uid)
    try{
        console.log(ChatId);
        const chatDocRef =doc(db, "chats", ChatId);
        const res = await getDoc(chatDocRef);
        console.log(res);
        await updateDoc(chatDocRef, {
            messages: arrayUnion({
              Id: uuid(),
              Text:text,
              SenderId: uid,
              Date: Timestamp.now(),
            }),
            LastMsg:{
                Id: uuid(),
                Text:text,
                SenderId: uid,
                Date: Timestamp.now(),
            }
        });
        await updateChatsArray (uid,ChatId.replace(uid,""), ChatId);
        return true;
    }
    catch (err){
        console.log(err)
        return false;
    }
   
}

const updateChatsArray = async (sender, receiver, chatid) => {
  
    try {
      // Get the current array from the document
      const userDocRef = doc(db, 'users', sender);
      const userDocSnapshot = await getDoc(userDocRef);
      const userData = userDocSnapshot.data();
      const currentChats = userData.Chats || [];
  
      // Remove the value from the array if it exists
      const filteredChats = currentChats.filter((chat) => chat !== chatid);
  
      // Add the value to the beginning of the array
      const updatedChats = [chatid, ...filteredChats];
  
      // Update the document with the new array
      await updateDoc(userDocRef,{
        Chats: updatedChats,
      });

      const user2DocRef = doc(db, 'users', receiver);
      const user2DocSnapshot = await getDoc(user2DocRef);
      const user2Data = user2DocSnapshot.data();
      const currentChats2 = user2Data.Chats || [];
  
      // Remove the value from the array if it exists
      const filteredChats2 = currentChats2.filter((chat) => chat !== chatid);
  
      // Add the value to the beginning of the array
      const updatedChats2 = [chatid, ...filteredChats2];
  
      // Update the document with the new array
      await updateDoc(user2DocRef,{
        Chats: updatedChats2,
      });
  
      console.log("updated",sender, receiver, chatid)
    } catch (error) {
      console.error('Error updating Chats array:', error);
    }
  };

  const addChat = async(userUid,FriendUid)=>{
    try{
        const chatdocRef = doc(db,'chats',userUid>FriendUid?userUid+FriendUid:FriendUid+userUid);
        const chatdata = await getDoc(chatdocRef);
        !chatdata.exists()? await setDoc(chatdocRef,{
            messages:[]
          }):"";
        
    }
    catch(err){
        console.log(err);
        
    }
}
const GetLastMsg = async (ChatId)=>{
    // console.log(ChatId)
    try{
        console.log(ChatId);
        const chatDocRef =doc(db, "chats", ChatId);
        const res = await getDoc(chatDocRef);
        const data = res.data();
        // console.log(data.LastMsg);
        
        return data.LastMsg;
    }
    catch (err){
        console.log(err)
        return {
            Id: 'Error',
            Text:'Error ',
            SenderId: 'Error ',
            Date: 'Error ',
        };
    }
   
}


export {
 addUserInfotoCloudDB,
 addChat,
 ChatList,
 userInfo,
 updateInfoarray,
 SendTxt,
 updateChatsArray,
 GetLastMsg
};