import React, { useContext, useEffect, useRef } from "react";
import { UserAuth } from "../Context/AuthContext";


const Message = ({ message }) => {
  const { user ,placeholderurl} = UserAuth();
 

  const ref = useRef();

  useEffect(() => {
    ref.current?.scrollIntoView({ behavior: "smooth" });
  }, [message]);

  return (

    // <div
    //   ref={ref}
    //   className={`message ${message.SenderId === user.uid && "owner"}`}
    // >
    //   <div className="messageInfo">
    //     <img
    //       src={
    //         message.SenderId === user.uid
    //           ? user.photoURL
    //           : placeholderurl
    //       }
    //       alt=""
    //       className="w-8 h-8 rounded-full object-cover"
    //     />
        
    //   </div>
    //   <div className="messageContent">
    //     <p>{message.Text}</p>
    //     {message.img && <img src={message.img} alt="" />}
    //   </div>
    // </div>
  
    <div class={` ${message.SenderId === user.uid ? "me":"frind"}   mt-3  grid justify-items-end text-left text-white `}>
        <div class="flex flex-row ">
            <p class="bg-blue-600  p-2 text-xl  rounded-b-xl rounded-l-xl"> {message.Text}  </p>
            <a href="#"> <img src={message.SenderId === user.uid
              ? user.photoURL
              : placeholderurl} alt="" class="rounded-full w-10 h-10 mx-2 "/></a>
        </div>
      </div>
  );
};

export default Message;
