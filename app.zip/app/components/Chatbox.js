import React, { useEffect, useState } from 'react';
import { UserAuth } from '../Context/AuthContext';
import Messages from './messages';
import { userInfo } from '../firedb';
import Input from '@/app/components/input';
const Chatbox = ({uid}) => {
    // console.log(uid);
    const { user,placeholderurl } = UserAuth();
    
    const [info,setInfo] = useState({
        Uid:"",
        PhotoUrl:"",
        Email:"",
        Fullname:""
    })


    const id = uid;
    const chatId = user ? user.uid > id ? user.uid + id : id + user.uid : "loading";
  console.log(chatId);
  useEffect(()=>{
    userInfo(id).then((r)=>{
        setInfo(r);
        console.log(info);
    }
   

    ) 
    
   
},[id])

    return (
       
            <div id="third " class="w-full xl:col-span-8 lg:col-span-7 md:col-span-11 sm:col-span-10 col-span-10 px-3  h-screen  " >
            <div class="h-screen  flex flex-col justify-between ">
                <div class="pt-4  bg-gray-200">
                    <div class="  flex  justify-between">
                        <div class="flex items-center">
                        <div >
                            <a href="#"> <img src={info&&info.PhotoUrl || placeholderurl} alt="" class="rounded-full w-12 h-12  "/></a>
                        </div>
                        <div class="ml-4">
                            <strong>{info&&info.Fullname || 'User Name'} </strong>
                            
                        </div>
                        </div>
                        
        
                        </div>
                        {/* <hr class="m-x-1 mt-2"/> */}
                    
                
                </div>
    
    
    <div class="overflow-auto">   
    <Messages ChatId={chatId} />
    </div>    
    
    
    
    
    
                <div class="">
                    {/* input  */}
                    <Input ChatId={chatId}/>
                </div>
    
            </div>
    
        </div>
        
    );
}

export default Chatbox;
