'use client'
import Header from '@/app/Header/navbar';
import Chatbox from '@/app/components/Chatbox';
import Chatlist from '@/app/components/Chatlist';
import React, { useEffect, useState } from 'react';

const Page = () => {
    const [activeChat, setactiveChat] = useState("");
    useEffect(() => {
        // Code to run when activeChat changes
        // For example, you can update some state or perform an action here
        // In this case, let's just log the change for demonstration purposes
        console.log('Active chat changed:', activeChat);
    }, [activeChat]);

    return (
        <div class="grid grid-cols-12  h-screen ">
            <Header/>
            <Chatlist setactive={setactiveChat}/>
            <Chatbox uid = {activeChat}/>
            
        </div>
    );
}

export default Page;
