'use client'
import React, { useEffect, useState } from 'react';
import { UserAuth } from '../Context/AuthContext';
import Spinner from '../components/Spinner';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ChatList,  userInfo } from '../firedb';
import FriendCard from '../components/Friendcard';

const Page = () => {
     const {user,auth,isLoggedIn, setLoggedin } =  UserAuth();
    
    const [loading, setLoading] = useState(true);

    // console.log(user);

  useEffect(() => {
    const checkAuthentication = async () => {
      await new Promise((resolve) => setTimeout(resolve, 500));
      setLoading(false);
      
    };
    checkAuthentication();
  }, [user]);
  const router = useRouter();
  const [ChatLst , setChatLst] = useState([]);
  useEffect(()=>{
    const updatelist = async () => {
         const res = await ChatList(user?user.uid:"");
         setChatLst(res);
         console.log(res);
        
      };
      updatelist();

  },[user])

  
    return (
        <div>
            {loading?(<Spinner/>):(user?(
             <div className="min-h-screen bg-gray-100">
             <header className="bg-blue-500 py-4 text-white text-center">
                 <h1 className="text-3xl font-semibold">Welcome to E-Barta</h1>
                 <p>An End-to-End Encrypted Messenger</p>
                 <p>{user.email}</p>
             </header>
             <div className="container mx-auto py-6">
                 <div className="grid grid-cols-4 gap-4">
                     <div className="col-span-3">
                         <h2 className="text-2xl font-semibold mb-4">Recent Conversations</h2>
                         <div className="bg-white p-4 rounded shadow-md">
                             {/* Iterate through recent conversations and display messages */}
                             <div className="mb-4">
                                 <Link legacyBehavior  href="/chat/username">
                                     <a className="text-blue-500 hover:underline">Friend 1</a>
                                 </Link >
                                 <p>Last message content</p>
                             </div>
                             <div className="mb-4">
                                 <Link legacyBehavior  href="/chat/username">
                                     <a className="text-blue-500 hover:underline">Friend 2</a>
                                 </Link >
                                 <p>Last message content</p>
                             </div>
                             {/* Add more recent conversations */}
                         </div>
                     </div>
                     <div className="col-span-1">
                         <h2 className="text-2xl font-semibold mb-4">Friend List</h2>
                         <div className="bg-white p-4 rounded shadow-md">
                         {/* {ChatLst && ChatLst.map(  (uid) => {
                               
                                return (
                                    <FriendCard
                                        key={uid}
                                        Uid={uid}
                                        
                                    />
                                    );
                                
                                
                                

                                
                            })} */}
                            
                             
                         </div>
                     </div>
                 </div>
             </div>
         </div>
            ):(<div>Please Login </div>))}
            
        </div>
    );
}

export default Page;
